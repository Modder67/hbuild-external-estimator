---
name: hbuild-external-estimator
description: Align external estimators with HBUILD client and project intake, H Ledger identity mappings, H Docs document delivery, and mesh ownership. Use when building or updating an estimator integration or checking its handoff; not for authoring estimates inside HBUILD.
---

# External estimator → HBUILD

## Outcome and status

External estimators create clients, projects, and estimates. HBUILD imports their
identity and scope, manages documents and operations, and displays authorized
information in H PANEL. Do not restore manual client/project creation in HBUILD.

This skill defines integration behavior; it does not install a connector or grant
access. As of 2026-09-24 the intake implementation is local, not verified live.
Manual creation retirement is prepared locally; migration 0020 and integration
release validation remain pending. Recheck deployment evidence before connecting.

## Ownership

| Concern | Authority and handoff |
|---|---|
| Client, project, estimate authoring | External estimator or explicitly designated upstream system |
| Provider accounts, external ID mappings, import/review status | H LEDGER; customers are local projections of external identities |
| Internal project ID, scheduling, assignments | H FORESIGHT (`planner`); Ledger provisions project identity through the gateway |
| Files, immutable versions, integrity, audience and released version | H DOCS (`docs`) |
| Floor plans, siteplan packets and operational timelines | H DRAFT (`draft`), based on imported scope |
| Actual financial facts and budget calculations | H LEDGER; accounting feed has a separate designated authority |
| Client/subcontractor access and presentation | H PANEL (`panel`), through scoped capabilities |

If Billdr and an estimator both refer to the same job, establish the authority
and explicit cross-provider mapping first. Never auto-merge on name, email,
address, or job code. Stable external IDs are account-scoped. Preserve existing
mesh IDs and records when linking an imported identity.

## Apply this skill efficiently

1. Read only the estimator's affected integration and [the intake contract](references/intake-contract.md).
   In the HBUILD workspace, consult `HBUILD-UPDATE-CONTRACT.md` for field authority
   and the affected Ledger/Docs manifests and skill link registries. Later owner
   decisions and current implementation supersede historical creation workflows.
2. Identify the source account, stable client/project/document IDs, source update
   times, outputs it actually produces, and target environment. Record unknowns;
   do not invent vendor triggers, credentials, APIs, approvals or customer data.
3. Reuse the signed Ledger intake. Keep one small server-side adapter per source
   format. No estimator database access, mesh credentials in a browser, extra
   gateway, event bus, or AI call for routine mapping, hashing or retries.
4. Deliver identity first, then project-bound documents. Track each delivery's
   result independently. Show pending/review/failed states until resolved.
5. Verify the acceptance cases below. Report implemented, tested, connected and
   production-verified separately. Update the owning contract only for actual changes.

## H Docs output rules

| Estimator output | Intake type | H Docs folder key | Intended use |
|---|---|---|---|
| Client proposal / estimate PDF | `proposal` | `estimates` | Client-facing scope and price, after explicit release |
| Material takeoff PDF | `takeoff` | `takeoffs` | Planning input; trade-safe version if it contains private pricing |
| Labor sheet PDF | `laborsheet` | `laborsheet` | Staff review; release only to the intended subcontractor |
| Proposed timeline PDF | `timeline` | `timelines` | Reference; does not create calendar events |

Declare only documents that the estimator is expected to deliver. A missing
expected output stays visibly missing; never substitute an empty PDF or mark it
verified. Floorplans, siteplans, budget files, receipts and Field Cam have separate
owner flows; their folder existence does not make them valid intake document types.

H LEDGER handles keyed folder provisioning, naming and H Docs upload/readback.
H DOCS owns file/version identity; retain source
IDs, revisions, original filenames and hashes. Do not create competing folder trees
or overwrite old versions to make a revised estimate appear current.

All imports start staff-only. Verification means successful file checks, not
client approval, contract acceptance, a signature, budget approval or release for
work. H PANEL reads only permitted released versions. A newer uploaded version
must not silently replace the version already released to a recipient.

The current document intake has no recipient field. Do not invent one. Keep labor
sheets staff-only until the existing H Docs release workflow binds the correct
person. If one source PDF contains multiple subcontractors' terms or internal
margin, require separate appropriate outputs before sharing. Never infer recipient
identity from the filename. No automated invitation, contract send or audience change
is implied by receiving an estimate.

## Preserve mesh operations

- Newer imported identity updates must not overwrite schedules, assignments,
  portal bindings, staff notes, release state or approved budget baselines.
- Estimate totals are selling prices, not actual costs or internal cost budgets.
  Do not double-count the same invoice/payment from an estimator, Billdr and QBO.
- PDF-only takeoffs and timelines remain documents. Structured quantities, totals,
  signatures and timeline publication require separately verified contracts.
  Unsupported fields are proposed extensions, not additions to today's strict JSON.
- A revised proposal does not automatically approve a change order, mark a job sold,
  alter payment state, assign crew, or release a siteplan. Preserve those owner flows.
- External imports use Ledger's retained `planner.createProject` capability.
  Do not call retired Draft enrollment or manual project/customer endpoints.

## Acceptance criteria

Use a disposable database/staging environment and real adapter-shaped fixtures.

- First delivery creates one mapped client/project and the project vault; supplied
  job code is preserved, absent job code remains absent.
- Replaying identical delivery creates no duplicate identity, file version or folder.
  A changed body with a reused delivery key is refused.
- A strictly newer source update applies; older/equal timestamps do not roll back
  state. Existing HBUILD operational fields remain unchanged.
- A same-name customer in another account or organization is not auto-linked.
  Mapping conflicts require explicit review; unauthorized/cross-org access fails.
- Each expected PDF is attached to the correct project, with validated size/hash
  and readback evidence. Corrupt/oversized files fail without false success.
- Missing Docs grants or temporary outage preserve imported identity and allow
  document retry without creating another project.
- New uploads remain staff-only. Clients/subcontractors cannot see internal budget,
  margin, someone else's labor sheet or unreleased revisions.
- Manual creation remains blocked. Existing records, planning and invitations work.

End integration work with a concise mapping of source → endpoint → HBUILD owner,
verified checks, remaining gaps and deployment status. A successful HTTP request
alone is not proof that all documents are verified or the integration is live.