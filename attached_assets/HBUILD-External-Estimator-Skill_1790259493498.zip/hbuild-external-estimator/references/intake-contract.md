# Ledger intake contract for estimator adapters

Evidence: local implementation inspected 2026-09-24 in
`hbuild-ledger/src/lib/intake/{rules,accounts,route,service}.ts` and
`src/app/api/intake/v1/{projects,documents}/route.ts`.
These are existing routes, not confirmation of production availability. Recheck
these files when implementing; do not treat this reference as a new API version.

## Authentication and delivery

Use HTTPS to the configured Ledger environment. A server-side provider account
binds the external source to one organization and an authorized acting user.
The body does not select an organization. Keep secrets in the adapter's server
secret store; never in frontend code, skill files, logs or uploaded documents.

Headers:
- `Content-Type: application/json`
- `x-hbuild-key`: provisioned account key ID
- `x-hbuild-timestamp`: current Unix timestamp in seconds
- `x-hbuild-signature`: lowercase hex HMAC-SHA256
- `Idempotency-Key`: stable unique delivery ID, unique across both endpoints

Current signing convention is important: HMAC key = the **hex string**
`SHA256(secret)`, not the raw secret or binary digest. Signed message =
`timestamp + '.' + rawJsonBody`. Serialize once, sign those exact bytes, send them.
The receiver allows 300 seconds of clock skew. Refresh timestamp/signature on a
retry while preserving delivery ID and body. Use the existing `signIntake` helper
where available; do not substitute the more usual raw-secret convention.

Store delivery state and immutable serialized body at the sender. Use bounded
backoff for transport errors/5xx; honor Retry-After on 429. Stop automatic retries
for invalid schema, invalid credentials or mapping conflicts and expose the reason.
After correction, changed payload gets a new delivery ID; an unchanged request
may reuse its original ID. Do not fake newer source timestamps to force acceptance.

Successful receipt outcomes are `applied` or `stale`; inspect returned document and
mapping status as well. Finished receipts replay; failed/review-needed operations
may not have a finished receipt, so the sender must retain its pending delivery.

## Identity request

`POST /api/intake/v1/projects` (JSON body limit 64 KiB).
One request includes the source state, client, project and expected output types.
Example uses fictional test data:

```json
{
  "source": {"updatedAt": "2026-09-24T18:00:00Z", "revision": "1"},
  "client": {
    "externalId": "customer-001",
    "firstName": "Test",
    "lastName": "Customer"
  },
  "project": {
    "externalId": "project-001",
    "projectType": "Deck",
    "name": "Back deck",
    "jobCode": "TEST-001"
  },
  "expectedDocuments": ["proposal", "takeoff", "laborsheet", "timeline"]
}
```

Client requires first/last name; optional phone, email and address. Project requires
externalId/projectType; optional name, jobCode and address. Address fields are
line1, line2, city, state, postalCode. Omit unavailable optional values; do not
invent data to satisfy required names. Both IDs are printable ASCII without spaces,
1–200 characters. Job code is display-only, max 20 letters/digits/hyphens, starting
with a letter/digit. Source updatedAt is an ISO instant with offset; revision is
an optional label. Freshness currently compares updatedAt, not revision labels.

Current identity API imports client + project together; it has no separate external
client-only endpoint. Keep estimator leads without a project upstream until there
is a real project, or propose a separate contract; never create placeholder jobs.

## Document request

`POST /api/intake/v1/documents` with the following shape. Replace the described
hash/base64 values with actual file data; these placeholders are not valid payloads.

```text
source: { updatedAt: ISO timestamp, revision?: source revision }
project: { externalId: previously imported project ID }
document: {
  externalId: stable source document ID,
  type: proposal | takeoff | laborsheet | timeline,
  originalName?: source filename,
  mime: application/pdf,
  sha256: 64 lowercase hex characters calculated from original PDF bytes,
  contentBase64: base64 of the same PDF bytes
}
```

PDF maximum: 8 MiB decoded; JSON body maximum: 12 MiB. No remote URL upload or
extra structured estimate fields are accepted. Ledger internally sends up to
4 MiB chunks through `docs.putVaultFile`, then verifies through readback; the
external sender does not call the mesh upload capability itself.

Keep document ID stable across revisions and advance its genuine source time.
Retain estimator output at the source until HBUILD confirms verified storage.
Use explicit document mapping and returned version references; a filename is
never the identity or permission boundary.

Ledger provisions nine keyed project folders in two calls because Docs accepts
at most eight paths per call: estimates, takeoffs, floorplans, siteplans, timelines,
laborsheet, budget, fieldcam, receipts. Do not rename existing keyed folders.

Current generated filename convention:
`JobID-Lastname-ProjectType-DocumentType-YYYY-MM-DD.pdf`.
Missing job code uses `NoJobID` in the filename only, not a fabricated identity.
Folder keys and returned IDs matter more than display labels.

## Separate future work from today's connection

Structured estimate lines/totals, multi-recipient labor-sheet delivery, external
signature evidence, client-only lead intake and automatic structured timeline
handoff are not provided by these two request schemas. For a requested extension,
identify the owner, versioned schema, auth/grants, revision/idempotency behavior,
consumer and tests before changing implementation. Do not revive old Draft
estimate or enrollment APIs to fill the gap.